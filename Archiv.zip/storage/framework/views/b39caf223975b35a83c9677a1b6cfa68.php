<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Başvuru Süreç Akışı')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-4 gap-6">
                <!-- Beklemede Sütunu -->
                <div class="bg-gray-100 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 mb-4">Beklemede</h3>
                    <div id="pending" class="min-h-[200px] bg-white rounded-lg p-4 shadow">
                        <?php $__currentLoopData = $pendingApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-blue-100 p-2 mb-2 rounded cursor-pointer" draggable="true" data-id="<?php echo e($application->id); ?>">
                                <strong><?php echo e($application->position); ?></strong><br>
                                <?php echo e($application->company_name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Görüşmeye Çağrıldı Sütunu -->
                <div class="bg-gray-100 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 mb-4">Görüşmeye Çağrıldı</h3>
                    <div id="interview" class="min-h-[200px] bg-white rounded-lg p-4 shadow">
                        <?php $__currentLoopData = $interviewApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-yellow-100 p-2 mb-2 rounded cursor-pointer" draggable="true" data-id="<?php echo e($application->id); ?>">
                                <strong><?php echo e($application->position); ?></strong><br>
                                <?php echo e($application->company_name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Teklif Sütunu -->
                <div class="bg-gray-100 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 mb-4">Teklif Alındı</h3>
                    <div id="offered" class="min-h-[200px] bg-white rounded-lg p-4 shadow">
                        <?php $__currentLoopData = $offeredApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-green-100 p-2 mb-2 rounded cursor-pointer" draggable="true" data-id="<?php echo e($application->id); ?>">
                                <strong><?php echo e($application->position); ?></strong><br>
                                <?php echo e($application->company_name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Reddedildi Sütunu -->
                <div class="bg-gray-100 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 mb-4">Reddedildi</h3>
                    <div id="rejected" class="min-h-[200px] bg-white rounded-lg p-4 shadow">
                        <?php $__currentLoopData = $rejectedApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-red-100 p-2 mb-2 rounded cursor-pointer" draggable="true" data-id="<?php echo e($application->id); ?>">
                                <strong><?php echo e($application->position); ?></strong><br>
                                <?php echo e($application->company_name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Kanban JS -->
    <script>
        document.querySelectorAll('[draggable="true"]').forEach(item => {
            item.addEventListener('dragstart', function (e) {
                e.dataTransfer.setData('application_id', e.target.getAttribute('data-id'));
            });
        });
    
        document.querySelectorAll('.min-h-[200px]').forEach(column => {
            column.addEventListener('dragover', function (e) {
                e.preventDefault();
            });
    
            column.addEventListener('drop', function (e) {
                e.preventDefault();
                let applicationId = e.dataTransfer.getData('application_id');
                let newStatus = e.target.id;
    
                // Sürüklenen öğeyi doğru hedefe taşımak için sütunu kontrol et
                let targetColumn = e.target.closest('.min-h-[200px]');
                
                // AJAX isteği ile durumu güncelle
                fetch(`/job-applications/${applicationId}/update-status`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({status: newStatus})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Güncellenen öğeyi yeni sütuna ekle
                        let draggedItem = document.querySelector(`[data-id="${applicationId}"]`);
                        targetColumn.appendChild(draggedItem);
                    } else {
                        alert('Durum güncellenirken bir hata oluştu.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            });
        });
    </script>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/asndk/job-application-tracker/resources/views/job-applications/kanban.blade.php ENDPATH**/ ?>