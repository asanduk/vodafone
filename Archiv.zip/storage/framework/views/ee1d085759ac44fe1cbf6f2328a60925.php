<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('İş Başvurusunu Düzenle')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <form action="<?php echo e(route('job-applications.update', $jobApplication->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group mb-4">
                        <label for="position" class="block text-gray-700">Pozisyon Adı</label>
                        <input type="text" name="position" id="position" class="form-control w-full" value="<?php echo e($jobApplication->position); ?>" required>
                    </div>

                    <div class="form-group mb-4">
                        <label for="company_name" class="block text-gray-700">Şirket Adı</label>
                        <input type="text" name="company_name" id="company_name" class="form-control w-full" value="<?php echo e($jobApplication->company_name); ?>" required>
                    </div>

                    <div class="form-group mb-4">
                        <label for="applied_at" class="block text-gray-700">Başvuru Tarihi</label>
                        <input type="date" name="applied_at" id="applied_at" class="form-control w-full" value="<?php echo e($jobApplication->applied_at); ?>" required>
                    </div>

                    <div class="form-group mb-4">
                        <label for="status" class="block text-gray-700">Durum</label>
                        <select name="status" id="status" class="form-control w-full">
                            <option value="pending" <?php echo e($jobApplication->status == 'pending' ? 'selected' : ''); ?>>Beklemede</option>
                            <option value="interview" <?php echo e($jobApplication->status == 'interview' ? 'selected' : ''); ?>>Görüşmeye Çağrıldı</option>
                            <option value="rejected" <?php echo e($jobApplication->status == 'rejected' ? 'selected' : ''); ?>>Reddedildi</option>
                            <option value="offered" <?php echo e($jobApplication->status == 'offered' ? 'selected' : ''); ?>>Teklif Alındı</option>
                        </select>
                    </div>

                    <div class="form-group mb-4">
                        <label for="job_listing_url" class="block text-gray-700">İş İlanı Linki</label>
                        <input type="url" name="job_listing_url" id="job_listing_url" class="form-control w-full" value="<?php echo e($jobApplication->job_listing_url); ?>">
                    </div>

                    <div class="form-group mb-4">
                        <label for="company_website_url" class="block text-gray-700">Firma Web Sitesi</label>
                        <input type="url" name="company_website_url" id="company_website_url" class="form-control w-full" value="<?php echo e($jobApplication->company_website_url); ?>">
                    </div>

                    <div class="form-group mb-4">
                        <label for="notes" class="block text-gray-700">Notlar</label>
                        <textarea name="notes" id="notes" class="form-control w-full"><?php echo e($jobApplication->notes); ?></textarea>
                    </div>

                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Güncelle
                    </button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/asndk/job-application-tracker/resources/views/job-applications/edit.blade.php ENDPATH**/ ?>